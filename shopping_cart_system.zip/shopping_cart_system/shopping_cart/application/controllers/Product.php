<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class Product extends CI_Controller {

  function __construct(){
    parent::__construct();
  }

  public function index(){
    $data['product'] = $this->product->get_product();
    $data['count'] = count(array_values(unserialize($this->session->userdata('cart'))));
    $this->load->view('product',$data);
  }

  public function add_product(){
    $data['product'] = $this->product->get_product();
    $this->form_validation->set_rules('product','Product','required');
    if($this->form_validation->run() == false){
      $this->load->view('product',$data);
    }else{
      $data = array(
        'product_name' => $this->input->post('product'),
        'price' => $this->input->post('price')
      );
      $result = $this->product->insert_data('product',$data);
      if($result > 0){
        redirect(base_url('Product/index'),$data);
      }

    }
  }
  
}