<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Master_model extends CI_Model
{

	public function insert_data($table,$data) {
		$this->db->insert($table,$data);
		return $this->db->insert_id();
	}

	public function get_product() {
		$query = $this->db->get('product');
		return $query->result();
	}

	public function getCartItems() {
    $sql='create query';
    return $this->db->query($sql)->result_array();
	}

    function get_single_product($id) {
        return $this->db->where('p_id', $id)->get('product')->row();
    }
}