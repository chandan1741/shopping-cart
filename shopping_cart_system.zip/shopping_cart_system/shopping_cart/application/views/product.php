<!DOCTYPE html>
<html lang="en">
<head>
  <title>Shopping cart</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style.css">

</head>

<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <div class="container">
        

        <div class="collapse navbar-collapse justify-content-end" id="navbarsExampleDefault">
           

            <form class="form-inline my-2 my-lg-0">
                <a class="btn btn-success btn-sm ml-3" href="<?php echo base_url();?>cart">
                    <i class="fa fa-shopping-cart"></i> Cart
                    <span class="badge badge-light"><?php echo $count;?></span>
                </a>
            </form>
        </div>
    </div>
</nav>

<div class="container">
  <div class="col-md-4">
    <h2>Product List</h2>
  </div>
  <div class="col-md-4">
    
  </div>
  <div class="col-md-4">
    <input type="button" name="add_product" id="add_product" class="btn btn-success" value="Add product" data-toggle="modal" data-target="#myModal">
    
  </div>
 
  <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      <form method="POST" action="<?php echo base_url();?>product/add_product">
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Add Product</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <div class="form-group">
            <input type="text" class="form-control" name="product" placeholder="Enter product name" required maxlength="30">
            </div>
            <div class="form-group">
            <input type="text" class="form-control" name="price" placeholder="Enter price" onkeypress="return isNumber(event)">
            </div>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-success" name="submit">Add</button>
        </div>
        </form>
      </div>
    </div>
  </div>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Sr.No.</th>
        <th>Product name</th>
        <!-- <th>Quentity</th> -->
        <th>Price</th>
        <th>Add to cart</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $i=0;
      foreach($product as $row){
      $i++;
      ?>
      <tr>
        <td><?php echo $i;?></td>
        <td><?php echo $row->product_name;?></td>
        <!-- <td><input type="text" name="quentity" value="1"></td> -->
        <td><?php echo $row->price;?></td>
        <td><a href="<?php echo site_url('cart/buy/'.$row->p_id); ?>">Add to cart</a></td>
      </tr>
     <?php } ?>
    </tbody>
  </table>
  
</div>
<script type="text/javascript">
    
        function isNumber(evt) {
        evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if (charCode > 31 && (charCode < 46 || charCode > 57 )) {
            return false;
        }
        return true;
      }
   
</script>
</body>
</html>
