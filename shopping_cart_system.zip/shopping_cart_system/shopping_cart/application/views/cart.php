<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style.css">
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <div class="container">
        <div class="collapse navbar-collapse justify-content-end" id="navbarsExampleDefault">
            <form class="form-inline my-2 my-lg-0">
                <a class="btn btn-success btn-sm ml-3" href="<?php echo base_url();?>cart">
                    <i class="fa fa-shopping-cart"></i> Cart
                    <span class="badge badge-light"><?php echo $count;?></span>
                </a>
            </form>
        </div>
    </div>
</nav>

<div class="container mb-4">
    <div class="row">
        <div class="col-12">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Product Name</th>
                            <th scope="col">Available</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Price</th>
                            <th scope="col">Action</th>
                            <!-- <th> </th> -->
                        </tr>
                    </thead>
                    <tbody>
                    	<?php 
                    	$i=0;
                    	foreach ($items as $item) { 
                    		// print_r($items);die;
                    	$i++;
                    	?>
                    	<tr>
                    		<td><?php echo $item['name'];?></td>
                    		<td>In stock</td>
                    		<td style="width: 25;">
                    		<?php echo $item['quantity'];?>
						</td>
                    		<td><?php echo $item['price'];?></td>
                    		<td><a href="<?php echo site_url('cart/remove/'.$item['id']); ?>" title="remove product"><i class="fa fa-remove" style="font-size:30px;color:red"></i></a></td>
                    	</tr>
                    <?php } ?>
        		</tr>
                    </tbody>
                    <tfoot>
                <tr>
                  <th></th>
                  <th></th>
                  <th>Total</th>
                  <th><?php echo $total;?></th>
                </tr>
                </tfoot>
                </table>
            </div>
        </div>
        <div class="col mb-2">
            <div class="row">
                <div class="col-sm-12  col-md-6">
                    <a href="<?php echo base_url('product');?>" class="btn btn-lg btn-block btn-success">Continue Shopping</a>
                </div>
            </div>
        </div>
    </div>
</div>

